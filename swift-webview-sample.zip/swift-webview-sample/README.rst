=====
About
=====

This is a basic sample of a hybrid application on MAC OS X system
HTML pages are rendered by WebView class which uses WebKit engine.
Interoperability between Swift and JavaScript is achieved.


.. rubric:: References

.. [#f1] http://www.markus-ullmann.de/posts/sample-to-bridge-between-javascript-and-swift-on-os-x-andor-ios.html
