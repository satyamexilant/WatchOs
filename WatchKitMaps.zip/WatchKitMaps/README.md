WatchKitMaps
===================
Source code demoing maps on Apple Watch. Find the tutorial at http://www.kristinathai.com/watchkit-tutorial-maps-on-the-apple-watch

[![Counter Demo](https://github.com/kristinathai/WatchKitMaps/blob/master/map.png)](http://www.kristinathai.com/watchkit-tutorial-maps-on-the-apple-watch)
