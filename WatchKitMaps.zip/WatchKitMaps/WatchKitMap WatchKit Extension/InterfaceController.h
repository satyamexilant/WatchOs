//
//  InterfaceController.h
//  WatchKitMap WatchKit Extension
//
//  Created by Thai, Kristina on 3/13/15.
//
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

@interface InterfaceController : WKInterfaceController

@end
