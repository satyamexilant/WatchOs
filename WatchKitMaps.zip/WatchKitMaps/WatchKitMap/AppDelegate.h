//
//  AppDelegate.h
//  WatchKitMap
//
//  Created by Thai, Kristina on 3/13/15.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

