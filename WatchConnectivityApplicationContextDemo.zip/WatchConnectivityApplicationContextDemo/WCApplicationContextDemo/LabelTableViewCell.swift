//
//  LabelTableViewCell.swift
//  WCApplicationContextDemo
//
//  Created by medidi vv satyanarayana murty on 11/07/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import UIKit

class LabelTableViewCell: UITableViewCell {

    @IBOutlet weak fileprivate var label: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configure(withText text: String) {
        label.text = text
    }

}
