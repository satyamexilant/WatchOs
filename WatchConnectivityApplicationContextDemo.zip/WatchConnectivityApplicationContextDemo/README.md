# WatchConnectivityApplicationContextDemo
Watch OS 2: Sharing data via WatchConnectivity's Application Context 

Blog post: [WatchConnectivity: Sharing The Latest Data via Application Context](http://natashatherobot.com/watchconnectivity-application-context/)
