//
//  DataSource.swift
//  WCApplicationContextDemo
//
//  Created by medidi vv satyanarayana murty on 11/07/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

struct DataSource {
    
    let item: Item
    
    enum Item {
        case food(String)
        case unknown
    }
    
    init(data: [String : AnyObject]) {
        if let foodItem = data["key"] as? String {
            item = Item.food(foodItem)
        } else {
            item = Item.unknown
        }
    }
}
