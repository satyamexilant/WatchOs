//
//  LIDocumentView.h
//  LIGridControl
//
//  Created by Mark Onyschuk on 2013-12-21.
//  Copyright (c) 2013 Mark Onyschuk. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface LIDocumentView : NSView

@end
