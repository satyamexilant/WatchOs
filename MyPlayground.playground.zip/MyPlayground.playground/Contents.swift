//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


var fruits = ["Apple","Grapes"]
var sort = find(fruits,"Apple")

