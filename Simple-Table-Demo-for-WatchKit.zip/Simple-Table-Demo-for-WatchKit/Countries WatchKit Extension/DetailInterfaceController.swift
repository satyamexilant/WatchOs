//
//  DetailInterfaceController.swift
//   Courses
//
//  Created by medidi vv satyanarayana murty on 11/07/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import WatchKit
import Foundation


class DetailInterfaceController: WKInterfaceController {
    
    @IBOutlet weak var countryName: WKInterfaceLabel!
    @IBOutlet weak var capital: WKInterfaceLabel!
    @IBOutlet weak var currency: WKInterfaceLabel!
    @IBOutlet weak var flag: WKInterfaceImage!
    
    let useage = [
        "Swift":"Ios Development",
        "Java":"Web Development",
        "C":"Low Level Design",
        "Linux":"Base of OS",
        "Core Java":"Web Development",
        "Advanced Java":"Web Development"
    ]
    
    let version = [
        "Swift":"3.2.1",
        "Java":"1.5.0",
        "C":"2.0.3",
        "Linux":"2.1.1",
        "Core Java":"1.5.1",
        "Advanced Java":"1.5.2"
    ]
    
    let icons =  [
        "Swift":"Swift",
        "Java":"java",
        "C":"C#",
        "Linux":"linux",
        "Core Java":"corejava",
        "Advanced Java":"advancedjava"
    ]
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        let name = context as! String
        countryName.setText(name)
        capital.setText(useage[name]!)
        currency.setText(version[name]!)
        flag.setImage(UIImage(named:icons[name]!))
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
}
