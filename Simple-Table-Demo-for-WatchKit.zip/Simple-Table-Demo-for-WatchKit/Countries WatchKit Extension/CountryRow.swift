//
//   CoursesRow.swift
//   Courses
//
//  Created by medidi vv satyanarayana murty on 11/07/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import WatchKit

class CountryRow: NSObject {
   
    @IBOutlet weak var countryName: WKInterfaceLabel!
}
