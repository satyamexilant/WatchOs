//
//  InterfaceController.swift
//   Courses WatchKit Extension
//
//  Created by medidi vv satyanarayana murty on 11/07/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    
    var courses = ["Swift", "Java", "C", "Linux", "Core Java", "Advanced Java"]

    @IBOutlet weak var tableView: WKInterfaceTable!
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
       setupTable()
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    func setupTable() {
        tableView.setNumberOfRows(courses.count, withRowType: "CountryRow")
        
        for i in 0 ..< courses.count {
            if let row = tableView.rowController(at: i) as? CountryRow {
                
                row.countryName.setText(courses[i])
                row.countryName.setTextColor(UIColor.orange)
                
            }
        }
    }

    override func table(_ table: WKInterfaceTable, didSelectRowAt rowIndex: Int) {
        self.pushController(withName: "showDetails", context: courses[rowIndex])
    }
}
