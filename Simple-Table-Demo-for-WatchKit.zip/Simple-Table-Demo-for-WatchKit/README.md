# Simple Table Demo for WatchKit
This is a simple table demo built using WatchKit. For the detailed tutorial, please refer it here:

http://www.appcoda.com/selectable-table-watchkit/
