//
//  DetailInterfaceController.swift
//  CountriesList
//
//  Created by medidi vv satyanarayana murty on 14/06/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import UIKit
import WatchKit

class DetailInterfaceController: WKInterfaceController {
    
    @IBOutlet weak var countryName: WKInterfaceLabel!
    @IBOutlet weak var capital: WKInterfaceLabel!
    @IBOutlet weak var currency: WKInterfaceLabel!
    @IBOutlet weak var flag: WKInterfaceImage!
    
    
    
    let capitals = ["Belgium":"Brussels",
                    "USA":"Washington DC",
                    "UK":"London",
                    "India":"New Delhi",
                    "China":"Beijing",
                    "Australia":"Canberra"]
    let currencies = ["Belgium":"EUR",
                      "USA":"USD",
                      "UK":"GBP",
                      "India":"INR",
                      "China":"CNY",
                      "Australia":"AUD"]
    let flags = ["Belgium":"be",
                 "USA":"us",
                 "UK":"gb",
                 "India":"in",
                 "China":"cn",
                 "Australia":"au"]
   
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        let name = context as! String
        countryName.setText(name)
       // capital.setText(capitals[name]!)
        //currency.setText(currencies[name]!)
        //flag.setImage(UIImage(named:flags[name]!))
    }
 
}
