//
//  CountryRow.swift
//  CountriesList
//
//  Created by medidi vv satyanarayana murty on 14/06/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import UIKit
import WatchKit

class CountryRow: NSObject {
    
    @IBOutlet var countryName: WKInterfaceLabel!

}
