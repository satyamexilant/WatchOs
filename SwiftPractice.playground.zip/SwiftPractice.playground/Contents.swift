//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


struct Days {
    let sunday, monday, tuesday: Int
    init(sunday: Int, monday: Int, tuesday: Int) {
        self.sunday = sunday
        self.monday = monday
        self.tuesday = tuesday
    }
    init(daysofaweek: Int) {
        sunday = daysofaweek
        monday = daysofaweek
        tuesday = daysofaweek
    }
}
let week = Days(sunday: 1, monday: 2, tuesday: 3)
print("Days of a Week is: \(week.sunday)")
print("Days of a Week is: \(week.monday)")
print("Days of a Week is: \(week.tuesday)")
let weekdays = Days(daysofaweek: 4)
print("Days of a Week is: \(weekdays.sunday)")
print("Days of a Week is: \(weekdays.monday)")
print("Days of a Week is: \(weekdays.tuesday)")




let someBits: UInt8 = 0b10110010
let moreBits: UInt8 = 0b01011110
let combinedbits = someBits | moreBits
print(combinedbits)
print(someBits)
print(moreBits)




var a = 10
var b = 20

swap(&a, &b)

print(a)


var num1 = 1
var num2 = 2
var num3:Int

print(num1)
print(num2)

num3 = num1
num1 = num2
num2 = num3

print(num1)
print(num2)


var arr = ["1", "2", "3", "4", "5"]



swap(&arr[2], &arr[1])
print(arr)





var s1 = "Left"
var s2 = "Right"

(s1,s2) = (s2,s1)



var num4 = 10
var num5 = 20

(num4,num5) = (num5,num4)

print(num4)
print(num5)



var string = ["tuples", "are", "awesome", "tuples", "are", "cool²",
    "tuples", "tuples", "tuples", "shades"]

var counts: [String: Int] = [:]

for item in string {
    counts[item] = (counts[item] ?? 0) + 1
}

//print(counts)
for (key, value) in counts {
    print("\(key) occurs \(value) time(s)")
    
}

