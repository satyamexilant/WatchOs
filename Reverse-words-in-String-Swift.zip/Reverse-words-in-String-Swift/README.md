Reverse-words-in-String-Swift
=============================

Reverse the order of the words in a given string

Given an example string like "Hello world!" the output would be "world! Hello".
