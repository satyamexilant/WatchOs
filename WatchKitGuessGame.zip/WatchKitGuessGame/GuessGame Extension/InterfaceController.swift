//
//  InterfaceController.swift
//  GuessGame Extension
//
//  Created by medidi vv satyanarayana murty on 19/06/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    
    
    @IBOutlet var guessSlider: WKInterfaceSlider!         // the slider
    @IBOutlet var guessLabel: WKInterfaceLabel!          // the label displaying the guess number
    @IBOutlet var resultLabel: WKInterfaceLabel!        // Wrong/Correct Label
    @IBOutlet var guessButton: WKInterfaceButton!
    @IBOutlet var randomSelectedNumber: WKInterfaceLabel!
    
    var guessNumber = 3
    @IBAction func updateGuess(_ value: Float) {
        
        guessNumber = Int(value * 10)
        guessLabel.setText("Your guess: \(guessNumber)")
    }
    
    @IBAction func startGuess() {
        
        let randomNumber = Int(arc4random_uniform(11))
        
        if(guessNumber == randomNumber) {
            
            resultLabel.setText("Guess Correct....!")
            randomSelectedNumber.setText("Random Numer is \(guessNumber)")
            randomSelectedNumber.setTextColor(#colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1))
            
            resultLabel.setTextColor(#colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1))
            guessButton.setBackgroundColor(#colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1))
            
        } else {
           
            resultLabel.setText("Guess Wrong. The number is \(randomNumber)")
            randomSelectedNumber.setTextColor(#colorLiteral(red: 1, green: 0.4932718873, blue: 0.4739984274, alpha: 1))
            resultLabel.setTextColor(#colorLiteral(red: 1, green: 0.4932718873, blue: 0.4739984274, alpha: 1))
            guessButton.setBackgroundColor(#colorLiteral(red: 1, green: 0.4932718873, blue: 0.4739984274, alpha: 1))
        }
    }
    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
