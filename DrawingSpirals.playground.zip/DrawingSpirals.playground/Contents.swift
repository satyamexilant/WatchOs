//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//
//var draw = Spiral(R:7,radius:3,d:4)
//draw.circleColor = UIColor.red





let encoder = JSONEncoder()
let jsonData = try! encoder.encode([42])
