//
//  ToDoListTableViewCell.m
//  ToDoList
//
//  Created by Mohammed Safwat on 9/20/15.
//  Copyright (c) 2015 safwat. All rights reserved.
//

#import "ToDoListTableViewCell.h"

@implementation ToDoListTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
