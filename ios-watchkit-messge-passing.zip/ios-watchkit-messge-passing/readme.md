A project that is used to demonstrate some different methods of message passing between iOS applications and WatchKit extensions:
* The first method is `openParentApplication:reply:`
* The second method is by using `MMWormhole` library.
* The third method is by using `NSUserDefaults`.
