//
//  ToDoListWatchKitTableRow.m
//  ToDoList
//
//  Created by Mohammed Safwat on 9/21/15.
//  Copyright (c) 2015 safwat. All rights reserved.
//

#import "ToDoListWatchKitTableRow.h"

@implementation ToDoListWatchKitTableRow

@end
