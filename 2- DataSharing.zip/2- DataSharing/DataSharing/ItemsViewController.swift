//
//  ItemsViewController.swift
//  DataSharing
//
//  Created by Konstantin Koval on 15/12/14.
//  Copyright (c) 2014 Konstantin Koval. All rights reserved.
//

import UIKit

class ItemsViewController: UITableViewController {
  
  var viewModel = ItemsViewModel()
  
  override func viewDidLoad() {
    super.viewDidLoad()
    tableView.tableFooterView = UIView()
  }
  
  @IBAction func createItem(_ sender: UITextField) {

    viewModel.append(sender.text!)
    sender.text = nil
    tableView.reloadData()
  }
  
  override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return viewModel.items.count
  }
  
  //  MARK: TableView
  override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
  {
    let cell = tableView.dequeueReusableCell(withIdentifier: "ItemCell", for: indexPath) 
    cell.textLabel?.text = viewModel.items[indexPath.row]
    return cell
  }
  
  override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
    return true
  }
  override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
   
    switch editingStyle {
    case .delete:
        viewModel.removeItemAt(indexPath.row)
      tableView.deleteRows(at: [indexPath], with: .fade)
    default:
        break
    }
  }
  
  func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    return textField.resignFirstResponder()
  }
}
