//
//  ItemsViewModel.swift
//  DataSharing
//
//  Created by Konstantin Koval on 15/12/14.
//  Copyright (c) 2014 Konstantin Koval. All rights reserved.
//

import Foundation

struct ItemsViewModel {

  fileprivate(set) var items: [String] = []
  
  init() {
    items = load()
  }
  
  mutating func append(_ item: String) {
    items.append(item)
    save(items)
  }
  
  mutating func removeItemAt(_ index: Int) {
    items.remove(at: index)
    save(items)
  }
  
  func save(_ items: [String]) {
    defaults?.set(items, forKey: itemsKey)
    print(defaults?.synchronize())
  }
  func load() -> [String] {
    return defaults?.object(forKey: itemsKey) as? [String] ?? []
  }
  
  fileprivate let itemsKey = "items"
  fileprivate let defaults = UserDefaults(suiteName: "group.com.kkoval.DataSharing")
}
