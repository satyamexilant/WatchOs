//
//  ItemRowController.swift
//  DataSharing
//
//  Created by Konstantin Koval on 16/12/14.
//  Copyright (c) 2014 Konstantin Koval. All rights reserved.
//

import Foundation
import WatchKit

class ItemRowController : NSObject {
  @IBOutlet weak var label: WKInterfaceLabel!
}
