//
//  ViewController.swift
//  AppsCommunication
//
//  Created by medidi vv satyanarayana murty on 17/07/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import UIKit


class PersonViewController: UIViewController {
  @IBOutlet fileprivate weak var personName: UILabel!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
  }
  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }
  
//MARK: - public 
  func showPerson(_ name: String) {
    personName.text = name
  }

  
  
}


