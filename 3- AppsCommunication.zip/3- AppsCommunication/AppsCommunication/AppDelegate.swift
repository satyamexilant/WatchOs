//
//  AppDelegate.swift
//  AppsCommunication
//
//  Created by medidi vv satyanarayana murty on 17/07/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

  var window: UIWindow?
  var personViewController: PersonViewController {
    return window?.rootViewController as! PersonViewController
  }

  func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
    // Override point for customization after application launch.
    return true
  }


  func application(_ application: UIApplication, handleWatchKitExtensionRequest
    userInfo: [AnyHashable: Any]?, reply: (([AnyHashable: Any]?) -> Void)?) {
   
    if let info = userInfo as? [String: String] {
      personViewController.showPerson(info["personName"]!)
      reply.map { $0(["response" : "success"]) }
    } else {
      reply.map { $0(["response" : "fail"]) }
    }
  }

}

