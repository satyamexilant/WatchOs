//
//  Detailed.swift
//  GlancesTableDemo
//
//  Created by medidi vv satyanarayana murty on 27/07/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import UIKit
import WatchKit

class Detailed: WKInterfaceController {

    @IBOutlet var detailedIcon: WKInterfaceImage!
   
    @IBOutlet var detailedLabel: WKInterfaceLabel!
    
       
   
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
    
        detailedLabel.setText(context! as? String)
    }
        override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
           
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    
}
