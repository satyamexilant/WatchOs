//
//  MyRowController.swift
//  GlancesTableDemo
//
//  Created by medidi vv satyanarayana murty on 27/07/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import UIKit
import WatchKit

class MyRowController: NSObject {
    
    @IBOutlet var icon: WKInterfaceImage!
    @IBOutlet var label: WKInterfaceLabel!


}
