//
//  InterfaceController.swift
//  GlancesTableDemo WatchKit Extension
//
//  Created by medidi vv satyanarayana murty on 27/07/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    
     @IBOutlet var myTable: WKInterfaceTable!
    let courseData = ["Swift", "Java", "linux", "Core Java", "Advanced Java", "C#"]
    
    let iconData = ["Swift", "java", "linux", "corejava", "advancedjava", "C#"]
    
    
    override init() {
        
        super.init()
        
        loadTable()
        
    }
    func loadTable() {
        
        myTable.setNumberOfRows(courseData.count,
                                withRowType: "MyRowController")
        
        
        for (index, labelText) in courseData.enumerated() {
            let row = myTable.rowController(at: index)
                as! MyRowController
            
            row.label.setText(labelText)
            row.icon.setImage(UIImage(named: iconData[index]))
        }
        
    }
    

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    
    override func table(_ table: WKInterfaceTable, didSelectRowAt rowIndex: Int) {
        self.pushController(withName: "showDetails", context: "Hai")
    }
}
