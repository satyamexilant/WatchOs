//
//  ViewController.swift
//  WatchConnectivity
//
//  Created by medidi vv satyanarayana murty on 18/07/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import UIKit
import WatchConnectivity

class ViewController: UIViewController {

    @IBOutlet var displayLabel: UILabel!
    @IBOutlet var textFieldData: UITextField!
    @IBOutlet var sendBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }

    @IBAction func sendBtn(_ sender: Any) {
        
    }

}

