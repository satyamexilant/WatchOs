//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white

        let label = UILabel()
        label.frame = CGRect(x: 150, y: 200, width: 200, height: 20)
        label.text = "Hello World!"
        label.textColor = .black
        
        view.addSubview(label)
        self.view = view
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()




//----------------------Ex-1 :- (MAP)---------------
//--------------------------------------------------

//let numbers = [ 10000, 10303, 30913, 50000, 100000, 101039, 1000000 ]
//var formattedNumbers: [String] = []
//for number in numbers {
//    let formattedNumber = NSNumberFormatter.localizedStringFromNumber(number, numberStyle: .DecimalStyle)
//    formattedNumbers.append(formattedNumber)
//}
//let formattedNumbers = numbers.map { NSNumberFormatter.localizedStringFromNumber($0, numberStyle: .DecimalStyle) }
//// [ "10,000", "10,303", "30,913", "50,000", "100,000", "101,039", "1,000,000" ]
//
//
//
//let arr = [1,2,3,4,5,6]
//print(arr.map{ return String($0 * 2)+"x" })
//print(arr.flatMap{ return String($0 * 2)+"x" })


let sequence = ["Aaa","Bbb","Ccc","Ddd"]
let sequence1 = sequence.map{$0.count}
let sequence2 = sequence.map{$0.lowercased()}
let sequence3 = sequence.map({$0.uppercased()})
let sequence4 = sequence.map{$0.hashValue}
let sequence5 = sequence.map({$0.startIndex})

sequence.map({ sequence.index(of: $0)! })
print("HashValues are \(sequence4)\n")
print("Main Sequence is \(sequence)\n")
print("Sub Sequence Count is \(sequence1)\n")
print("Lowered case Sequence  is \(sequence2)\n")
print("Upper case Sequence  is \(sequence3)\n")




let cast = ["Vivien", "Marlon", "Kim", "Karl"]
let lowercaseNames = cast.map { $0.lowercased()

}
    // 'lowercaseNames' == ["vivien", "marlon", "kim", "karl"]
let letterCounts = cast.flatMap { $0.count }
// 'letterCounts' == [6, 6, 3, 4]
print("\(lowercaseNames)\n")
print("\(letterCounts)\n")


//2

let numbers = [10, 30, 91, 50, 100, 39]
var formattedNumbers: [String] = []

for number in numbers {
         let formattedNumber = "\(number)$"
    formattedNumbers.append(formattedNumber)
}
print(formattedNumbers)


let mappedNumbers = numbers.map { "\($0)$" }



//FlatMap
let twoDimensionalArray = [[2, 3, 5], [22, 4, 6]]
let oneDimensionalArray = twoDimensionalArray.flatMap { $0 }
let oneDimensionalArray1 = twoDimensionalArray.joined().map { $0 }

let one = twoDimensionalArray.flatMap {$0.count}
let one1 = twoDimensionalArray.map{$0.count}




var a  = 10
var b = 20
print(a)
//swap(&a, &b)
print(a,b)

(a,b) = (b,a)
print(a,b)


