//
//  InterfaceController.swift
//  TestDemo Extension
//
//  Created by medidi vv satyanarayana murty on 19/07/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    

    
    @IBOutlet var displayLabel: WKInterfaceLabel!
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func plus() {
        
        increase()
        
    }
    
    @IBAction func minus() {
        
        decrement()
    }
    
    fileprivate (set) var count1 = 0
    func increase() {
        count1 += 1
        let count2 = String(count1)
        displayLabel.setText(count2)
    }
    
    func decrement() {
        count1 -= 1
        let count2 = String(count1)
        displayLabel.setText(count2)
    }
}
