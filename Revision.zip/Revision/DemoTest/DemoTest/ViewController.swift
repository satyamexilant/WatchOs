//
//  ViewController.swift
//  DemoTest
//
//  Created by medidi vv satyanarayana murty on 09/08/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

