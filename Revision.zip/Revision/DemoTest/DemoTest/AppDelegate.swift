//
//  AppDelegate.swift
//  DemoTest
//
//  Created by medidi vv satyanarayana murty on 09/08/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

