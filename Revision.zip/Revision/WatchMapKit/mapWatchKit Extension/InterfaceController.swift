//
//  InterfaceController.swift
//  mapWatchKit Extension
//
//  Created by medidi vv satyanarayana murty on 19/07/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import WatchKit
import Foundation
import MapKit


class InterfaceController: WKInterfaceController {
    @IBOutlet var myMapView: WKInterfaceMap!

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
       
        super.willActivate()
        let infiniteloopCoordinates  = CLLocationCoordinate2DMake(12.972442, 77.580643
)
        //let infiniteloopCoordinates  = CLLocationCoordinate2DMake(12.9716, 77.5946 )
        let areaSpan = MKCoordinateSpanMake(0.05, 0.05)
        let areaRegion = MKCoordinateRegionMake(infiniteloopCoordinates, areaSpan)
        
        myMapView.setRegion(areaRegion)
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
