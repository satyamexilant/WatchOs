//
//  ViewController.swift
//  DemoBGChange
//
//  Created by medidi vv satyanarayana murty on 25/07/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var myview: UIView!
    @IBOutlet var myImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }

    
    @IBAction func green(_ sender: Any) {
        
       // myview.backgroundColor = UIColor.green
        myImageView.image = UIImage(named:"green")
    }
    @IBAction func red(_ sender: Any) {
        
       // myview.backgroundColor = UIColor.red
        myImageView.image = UIImage(named:"red")
    }
    
    @IBAction func blue(_ sender: Any) {
        
        //myview.backgroundColor = UIColor.blue
        myImageView.image = UIImage(named:"blue")
    }
    
    @IBAction func clear(_ sender: Any) {
        
        // myview.backgroundColor = UIColor.gray
         myImageView.image = UIImage(named:"colorall")
        
    }
    
    func backgroundColorChange() {
        
    }

}

