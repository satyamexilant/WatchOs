//
//  ViewController.m
//  WebView
//
//  Created by medidi vv satyanarayana murty on 29/08/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

#import "ViewController.h"
#import <WebKit/WebKit.h>
@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];

//    NSString *urlText = @"https://google.com";
//    [[self.myWebViews mainFrame]loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:urlText]]];
//    return;
//
    NSString *urlString = @"https://mail.exilant.com";
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    [_myWebViews loadRequest:urlRequest];
    
//    NSString *urlText = @"https://mail.exilant.com";
//    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlText]];
//    [_myWebViews loadRequest:request];
    return;
    
    
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}



@end
