//
//  ViewController.h
//  WebView
//
//  Created by medidi vv satyanarayana murty on 29/08/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <WebKit/WebKit.h>

@interface ViewController : NSViewController
@property (strong) IBOutlet WKWebView *myWebViews;





@end

