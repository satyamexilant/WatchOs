//: Playground - noun: a place where people can play

import UIKit
//
//var str = "Hello, playground"
//
////
//let suits = ["L", "H", "F", "T"]
//
//let result = suits.flatMap { suit in
//    return suit + "r252"
//}
//
//print(result)
//
//
//
//let demo = ["Q","W","R","T"]
//let demo1 = demo.flatMap{ suit in
//    return suit  + "aq9"
//}
//print(demo1)
//
//
//
//
//
//let suits1 = ["Q","E","D"]
//let out = suits1.flatMap { dem -> String in
//print(dem + "d")
//    return dem + "d"
//}
//print(out)
//
//
//
//let suits2 = ["Q","W","S"]
//let out3 = suits2.map{ output in
//    //print(out3)
//    return output + "j"
//}
//print(out3)
//
//
//
//let number = [1,2,3,4,5,6,7,8,9]
//print("Remaining Numbers \(number.dropFirst(3))")
//print(number.dropLast(5))
//print(number.dropFirst(2))
//
//
//
//let arr = [1,2,3,4,5,6,10,1,4,6]
//print(arr.map{ return String($0 * 2)+"x" })
//
//print(arr.flatMap{ return String($0 * 2)+"x" })
//
//
//
//let arrayOfNumbers = [1, 2, 3, 4]
//let arrayOfString = arrayOfNumbers.map { "\($0)" }
//
//
//let mix = demo1
//let out1 = mix.count
//print("String Count Value is  = \(out1)" +   "\(demo1)")
//
//
//
//
//
//
////Optionals
//
//var message:String?
//message = "Hi How Are You"
//print(message!)
//



var strings = ["tuples", "are", "awesome", "tuples", "are", "cool",
               "tuples", "tuples", "tuples", "shades"]

var counts:[String:Int] = [:]


for item in strings {
    counts[item] = (counts[item] ?? 0) + 1 }

for (key, value) in counts {
    print("\(value) - \(key)") }

