//
//  main.m
//  StudentInfo
//
//  Created by medidi vv satyanarayana murty on 29/08/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
