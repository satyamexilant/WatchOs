//
//  AppDelegate.m
//  StudentInfo
//
//  Created by medidi vv satyanarayana murty on 29/08/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {

}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}


@end
